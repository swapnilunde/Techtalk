package techtalk.pojo;

public class RequestedTechTalk {

	private int reqid;
	private int empid;
	private String topic;
	
	private String Status;
	
}
