package techtalk.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletContext;

import techtalk.pojo.User;

public class UserDao extends  Dao{

	PreparedStatement insertStatement;
	PreparedStatement selectStatement;
	
	{
		this.insertStatement = this.connection.prepareStatement("insert into user values(?,?,?,?,?)");
		this.selectStatement = this.connection.prepareStatement("select * from user where email=? and password=?");
	}

	public UserDao() throws Exception
	{
		super(); 
	}
	public UserDao(ServletContext context) throws Exception
	{
		super(context);
	}
	public UserDao(String driver, String url, String user, String password)throws Exception
	{
		super(driver, url, user, password);
	}
	
	public User validateUser( String name, String password )throws SQLException
	{
		this.selectStatement.setString(1, name);
		this.selectStatement.setString(2, password);
		ResultSet rs = this.selectStatement.executeQuery();
		User user = null;
		if( rs.next())
		{
			user = new User(rs.getInt("empid"), rs.getString("name"),password,rs.getString("email"),rs.getString("role"));
		System.out.println(user.getEmail());
		}
		return user;	
		
	}
	public int registerNewUser( User user )throws SQLException
    {
        this.insertStatement.setInt(1,user.getEmpid());
        this.insertStatement.setString(2, user.getName());
        this.insertStatement.setString(4, user.getEmail());
        this.insertStatement.setString(3,user.getPassword());
        this.insertStatement.setString(5, (String) user.getRole());
    
        return this.insertStatement.executeUpdate();
    }
	
}
